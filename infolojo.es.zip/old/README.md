# infolojo.es
web personal
Queda terminar
    *Estructura
    *Revision de estilo
    *limpieza de codigo
    *Programacion enlazes y efectos
